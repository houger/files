sbt-new-project
===============

shell script create a new sbt project

Run script`./sbt_new_project`

```sh
$ 当前目录是：/ROOT/scripts/sbtNewProject
$ 请输入项目名称，如果不如将使用默认的项目名称project_name：
>sbt_project_test
$请输入项目的版本号，默认是0.1-SNAPSHOT:
>1.0
$请输入scala的版本，默认使用2.10.0：
>2.9.2
$请输入sbt的版本，默认使用0.12.3:
>0.12.0
$请输入 organization,默认是com.example:
>com.ruifeng.sun
```

